﻿namespace Sqlcnn
{
    internal class sqlconnection
    {
    }
}