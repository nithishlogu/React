﻿using System;
using System.Data.SqlClient;

namespace Sqlcnn
{
    class Prog
    {
        public static void Main()
        {
            SqlConnection my_sql;
            string connectionString = @"Data Source=DESKTOP-6A43OVG\SQLEXPRESS;Initial Catalog=db;Integrated Security=True";
            do
            {
                my_sql = new SqlConnection(connectionString);
                my_sql.Open();
                Console.WriteLine("Enter name");
                string a = Console.ReadLine();
                Console.WriteLine("enter id");
                int b = int.Parse(Console.ReadLine());
                string insert = "insert into sample1('" + a + "'," + b +")"; 
                SqlCommand insertComand = new SqlCommand(insert,my_sql);
                insertComand.ExecuteNonQuery();
            }
            while (true);
        }

    }
}