﻿using System;
namespace m_cast_dele
{
    public delegate void deleg(); //delegate assign
    class Program
    {
        class C1 //class creation
        {
            public int id;
            public string name;
            public int salary1;
            public void employee() //meathod creation
            {
                Console.WriteLine(id);
                Console.WriteLine(name);
            }
            public void salary()
            {
                Console.WriteLine("asergyu");
            }
        }
        public static void Main()
        {
            deleg delegname; //creating delegate
            C1 c = new C1(); //creating object for class
            c.id = 10;
            c.name = "anura";
            c.salary1 = 10009876;
            delegname = c.salary;
            delegname += c.employee; //assigning meathods to delegate
            delegname();//calling delegate
            Console.ReadLine();

        }
    }
}