﻿using System;
namespace s_deleg
{
    public class program
    {
        public delegate void My_delegate();
        class sys1
        {
            public int a;
            public int b;
            public int c;
            public void add()
            {
                c = a + b;
                Console.WriteLine(c);
            }
            public void result()
            {
                Console.WriteLine("multicast");
            }
            public static void Main()
            {
                My_delegate meath;
                sys1 sys = new sys1();
                sys.a = 20;
                sys.b = 200;

                meath = sys.add;
                meath += sys.result;
                meath();
            }
        }
    }
}