﻿using System;
public class ifexample
{
    public static void Main(string[] args)
    {
    again:
        {
            Console.WriteLine("\n!-------------------------------------------------------------!");
            Console.WriteLine("Enter use type(Domestic/Commercial/Agri) :");
            string type = Console.ReadLine();
            string type1 = type.ToLower(); 
            Console.WriteLine("Enter your Area(City/Vown/Village");
            string area1 = Console.ReadLine();
            string area = area1.ToLower();
            Console.WriteLine("enter the name :");
            string name = Console.ReadLine();
            Console.WriteLine("enter service number :");
            int address = int.Parse(Console.ReadLine());
            Console.WriteLine("enter the unit");
            dynamic unit = int.Parse(Console.ReadLine());
            Console.WriteLine("\n!-------------------------------------------------------------!");
            Console.WriteLine("TNEB BILL STATEMENT");
            Console.WriteLine("\nName : " + name);
            Console.WriteLine("Service number : " + address);
            Console.WriteLine("Units consumed : " + unit);
            switch (type1)
            {
                case "domestic":
                    if (unit <= 1000)
                    {
                        int tarrif = unit * 5;
                        if (area == "Town")
                        {
                            Console.WriteLine("Your Bill Amount Is : " + (tarrif + (tarrif / 100) * 2));
                        }
                        else if (area == "City")
                        {
                            Console.WriteLine("Your Bill Amount Is : " + (tarrif + (tarrif / 100) * 5));
                        }
                        else
                        {
                            Console.WriteLine("Your Bill Amount Is : " + tarrif);
                        }
                    }
                    else if (unit > 1000 && unit <= 10000)
                    {
                        int tarrif = (5000 + (unit - 1000) * 25);
                        if (area == "Town")
                        {
                            Console.WriteLine("Your Bill Amount Is : " + (tarrif + (tarrif / 100) * 2));
                        }
                        else if (area == "City")
                        {
                            Console.WriteLine("Your Bill Amount Is : " + (tarrif + (tarrif / 100) * 5));
                        }
                        else
                        {
                            Console.WriteLine("Your Bill Amount Is : " + tarrif);
                        }
                    }
                    else if (unit > 10000 && unit <= 20000)
                    {
                        int tarrif = (230000 + (unit - 10000) * 50);
                        if (area == "Town")
                        {
                            Console.WriteLine("Your Bill Amount Is : " + (tarrif + (tarrif / 100) * 2));
                        }
                        else if (area == "City")
                        {
                            Console.WriteLine("Your Bill Amount Is : " + (tarrif + (tarrif / 100) * 5));
                        }
                        else
                        {
                            Console.WriteLine("Your Bill Amount Is : " + tarrif);
                        }
                    }
                    else
                    {
                        int tarrif = (730000 + (unit - 20000) * 100);
                        if (area == "Town")
                        {
                            Console.WriteLine("Your Bill Amount Is : " + (tarrif + (tarrif / 100) * 2));
                        }
                        else if (area == "City")
                        {
                            Console.WriteLine("Your Bill Amount Is : " + (tarrif + (tarrif / 100) * 5));
                        }
                        else
                        {
                            Console.WriteLine("Your Bill Amount Is : " + tarrif);
                        }
                        
                    }
                    break;
                case "commercial":
                    if (unit <= 1000)
                    {
                        int tarrif = unit * 15;
                        if (area == "Town")
                        {
                            Console.WriteLine("Your Bill Amount Is : " + (tarrif + (tarrif / 100) * 2));
                        }
                        else if (area == "City")
                        {
                            Console.WriteLine("Your Bill Amount Is : " + (tarrif + (tarrif / 100) * 5));
                        }
                        else
                        {
                            Console.WriteLine("Your Bill Amount Is : " + tarrif);
                        }
                    }
                    else if (unit > 1000 && unit <= 10000)
                    {
                        int tarrif = (15000 + (unit - 1000) * 40);
                        if (area == "Town")
                        {
                            Console.WriteLine("Your Bill Amount Is : " + (tarrif + (tarrif / 100) * 2));
                        }
                        else if (area == "City")
                        {
                            Console.WriteLine("Your Bill Amount Is : " + (tarrif + (tarrif / 100) * 5));
                        }
                        else
                        {
                            Console.WriteLine("Your Bill Amount Is : " + tarrif);
                        }
                    }
                    else if (unit > 10000 && unit <= 20000)
                    {
                        int tarrif = (375000 + (unit - 10000) * 70);
                        if (area == "Town")
                        {
                            Console.WriteLine("Your Bill Amount Is : " + (tarrif + (tarrif / 100) * 2));
                        }
                        else if (area == "City")
                        {
                            Console.WriteLine("Your Bill Amount Is : " + (tarrif + (tarrif / 100) * 5));
                        }
                        else
                        {
                            Console.WriteLine("Your Bill Amount Is : " + tarrif);
                        }
                    }
                    else
                    {
                        int tarrif = (1075000 + (unit - 20000) * 100);
                        if (area == "Town")
                        {
                            Console.WriteLine("Your Bill Amount Is : " + (tarrif + (tarrif / 100) * 2));
                        }
                        else if (area == "City")
                        {
                            Console.WriteLine("Your Bill Amount Is : " + (tarrif + (tarrif / 100) * 5));
                        }
                        else
                        {
                            Console.WriteLine("Your Bill Amount Is : " + tarrif);
                        }
                        
                    }
                    break;
                case "agri":
                    Console.WriteLine("\n");
                    Console.WriteLine("Free for Agriculture");
                    break;
                default:
                    Console.WriteLine("Invalid use");
                    Console.WriteLine("onlt for Domestic,Commercial,Agri");
                    break;
                    
            }
        }
        Console.WriteLine("\n!-------------------------------------------------------------!");
        Console.WriteLine("TNEB BILL STATEMENT", "\n");
        Console.WriteLine("To Continue type yes");
        string cnt = Console.ReadLine();
        string cnt1 = cnt.ToLower();
        if(cnt1 == "yes")
        {
            goto again;
        }
    }
}